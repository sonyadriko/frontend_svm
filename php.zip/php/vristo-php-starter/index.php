<?php include 'header-main.php'; ?>

<div>
    <h1>starter kit</h1>
</div>
<?php include 'footer-main.php'; ?>
